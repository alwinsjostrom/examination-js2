const app = require('./index');
const coffeRouter = require('./routes/index');
const cors = require('cors');
const PORT = 8080;

app.use(cors());
app.use('api/coffee', coffeRouter);

app.listen(PORT, (err) => {
    if (err) throw err
    console.log('Server is running on http://localhost:8080')
});