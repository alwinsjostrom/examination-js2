const { Router } = require('express');
const router = new Router();
const fs = require('fs');

router.get('/', (req, res) => {
    const coffee = fs.createReadStream('data/coffee.json');
    coffee.pipe(res)
});

module.exports = router;