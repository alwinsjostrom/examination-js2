import React from 'react';
import MenuItem from '../components/menuItem';
import MenuBtn from '../components/menuBtn';
import NavMenu from '../components/navMenu';
import Bag from '../components/bag';
import BagBtn from '../components/bagBtn';
import coffeeList from '../assets/coffee.json';
import '../styles/menu.css'

const Menu = () => {

    return (

        <section className="menu__container">
            <NavMenu />
            <nav className="menu--container__main--nav">
                <MenuBtn />
                <BagBtn />
            </nav>
            <Bag />
            <article className="menu--container__items">
                <h1>Meny</h1>
                {
                    coffeeList.map((coffee, index) => <MenuItem item={coffee} index={index} key={index} />)
                }
            </article>
        </section>
    );
};

export default Menu;