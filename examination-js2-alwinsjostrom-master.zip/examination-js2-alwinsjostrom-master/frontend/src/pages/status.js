import React from 'react';
import drone from '../assets/drone.svg';
import '../styles/status.css';

//Randomizing order number and delivery-time
let minutes = Math.floor((Math.random() * 15) + 1);
let order1 = Math.floor((Math.random() * 100) + 1);
let order2 = Math.floor((Math.random() * 30) + 1);

const Status = () => {
    return (
        <section className="status__container">
            <h4>Ordernummer <span>{"#" + order1 + "DV" + order2 + "F"}</span></h4>
            <img src={drone} alt="drone"></img>
            <h1>Din beställning är på väg!</h1>
            <h3>{minutes + " minuter"}</h3>
            <button>Ok, cool!</button>
        </section>
    );
};

export default Status;