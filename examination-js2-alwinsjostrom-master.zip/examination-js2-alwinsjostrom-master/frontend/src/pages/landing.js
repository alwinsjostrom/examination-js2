import React from 'react';
import logo from '../assets/airbean-landing.svg';
import { Link } from 'react-router-dom';
import '../styles/landing.css';

const Landing = () => {
    return (
        <Link to="/about">
            <section className='landing__container'>
                <img src={logo} alt="Logotype"></img>
            </section>
        </Link>
    );
};

export default Landing;