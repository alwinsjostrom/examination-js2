export const increment = (index) => {
    return {
        type: 'INCREMENT',
        payload: { index }
    };
};

export const decrement = (index) => {
    return {
        type: 'DECREMENT',
        payload: { index }
    };
};

export const addItems = (index) => {
    return {
        type: 'ADDITEM',
        payload: { index }
    };
};

export const removeItems = (index) => {
    return {
        type: 'REMOVEITEM',
        payload: { index }
    };
};