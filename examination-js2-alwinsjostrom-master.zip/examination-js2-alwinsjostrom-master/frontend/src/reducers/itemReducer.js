const initialState = [];

//This is for the array of bagged items
const itemReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADDITEM':
            if (state.includes(action.payload.index) === false) {
                return state = [...state, action.payload.index]
            } else {
                return state;
            }

        case 'REMOVEITEM':
            let newArr = state;
            newArr.splice(state.indexOf(action.payload.index), 1);
            return state = newArr;

        default:
            return state;
    };
};

export default itemReducer;