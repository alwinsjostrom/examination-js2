import counterReducer from './counterReducer';
import itemReducer from './itemReducer';
import { combineReducers } from 'redux';

//Combining my reducers
const allReducers = combineReducers({
    counters: counterReducer,
    items: itemReducer
});

export default allReducers;