import './App.css';
import { Route, BrowserRouter as Router } from 'react-router-dom';
import Landing from './pages/landing';
import About from './pages/about';
import Menu from './pages/menu';
import Status from './pages/status';

function App() {
  return (
    <Router>
      <div className="App">
        <Route exact path='/' component={Landing} />
        <Route exact path='/about' component={About} />
        <Route exact path='/menu' component={Menu} />
        <Route exact path='/status' component={Status} />
      </div>
    </Router>
  );
};

export default App;