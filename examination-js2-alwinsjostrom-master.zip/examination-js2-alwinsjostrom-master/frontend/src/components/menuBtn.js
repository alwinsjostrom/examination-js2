import React from 'react';
import navIcon from '../assets/navicon.svg';

const MenuBtn = () => {

    //Toggle menu for navigation
    const openMenu = () => {
        document.querySelector('.nav__menu').classList.toggle('hide');
        document.querySelector('.nav__menu').style.transform = "translateX(0)";
    };

    return (
        <button className="menu__btn">
            <img src={navIcon} alt="Menu icon" onClick={openMenu}></img>
        </button>
    );
};

export default MenuBtn;