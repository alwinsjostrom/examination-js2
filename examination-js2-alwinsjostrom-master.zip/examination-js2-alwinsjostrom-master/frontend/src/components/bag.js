import React from 'react';
import BagItem from '../components/bagItem';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import coffeeList from '../assets/coffee.json';

const Bag = () => {

    //Saving the states from redux store
    const items = useSelector(state => state.items);
    const counter = useSelector(state => state.counters);

    //Variable that holds the total price
    let totalPrice = 0;

    //Add the amounts to get the total
    for(let i = 0; i < counter.length; i++) {
        totalPrice += counter[i] * coffeeList[i].price;
    };

    return (

        <section className="bag__container hide">
            <h2 className="bag--container__title">Din beställning</h2>
            {
                items.map((item, index) => <BagItem chosen={item} key={index} />)
            }
            <article className="bag--container__bottom">
                <h2 className="bag--container__total">Total </h2>
                <h2 className="bag--container__price">{totalPrice + " kr"}</h2>
                <p className="bag--container__info">inkl moms + drönarleverans</p>
            </article>
            <Link to="/status"><button className="bag--container__btn">Take my money!</button></Link>
        </section>
    )
};

export default Bag;