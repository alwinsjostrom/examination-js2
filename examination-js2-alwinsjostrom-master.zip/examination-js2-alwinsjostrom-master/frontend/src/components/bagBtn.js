import React from 'react';
import bagIcon from '../assets/bag.svg';
import { useSelector } from 'react-redux';

const BagBtn = () => {
    
    //Total items added to bag
    const counter = useSelector(state => state.counters);
    const totalCount = counter[0] +
                       counter[1] +
                       counter[2] +
                       counter[3] +
                       counter[4] +
                       counter[5]
    ;

    //Toggle shopping bag
    const showBag = () => {
        document.querySelector('.bag__container').classList.toggle('hide');
        document.querySelector('.menu--container__items').classList.toggle('hide');
        document.querySelector('.bag__container').style.transform = "translateX(0)";
    };

    return (
        <button className="bag__btn" onClick={showBag}>
            <img src={bagIcon} alt="Bag icon"></img>
            <h3 className="bag__amount">{totalCount}</h3>
        </button>
    );
};

export default BagBtn;