import React from 'react';
import close from '../assets/close.svg';
import { Link } from 'react-router-dom';

const NavMenu = () => {

    //Toggle menu for navigation
    const closeMenu = () => {
        document.querySelector('.nav__menu').classList.toggle('hide');
        document.querySelector('.nav__menu').style.transform = "translateX(0)";
    };

    return (
        <section className="nav__menu hide">
            <button onClick={closeMenu}><img src={close} alt="close"></img></button>
            <article className="nav--menu__container">
                <Link to="/menu"><h2>Meny</h2></Link>
                <h2>Vårt kaffe</h2>
                <h2>Min profil</h2>
                <h2>Orderstatus</h2>
            </article>
        </section>
    );
};

export default NavMenu;