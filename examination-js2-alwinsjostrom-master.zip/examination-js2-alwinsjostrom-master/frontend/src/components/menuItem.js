import React from 'react';
import add from '../assets/add.svg';
import { useDispatch } from 'react-redux';
import { increment, addItems } from '../actions';

const MenuItem = (props) => {

    //Variable regarding my redux store
    const dispatch = useDispatch();

    //Function for adding an item to the bag
    const addItem = (event) => {
        //Increase total count of individual items in bag
        dispatch(increment(props.index));
        //Add item to array of bagged items
        dispatch(addItems(props.index));
    };

    return (
        <section className="menu--container__item">
            <button className="add__btn" onClick={addItem}><img src={add} alt="+"></img></button>
            <h2 className="item__underscore">{props.item.name}</h2>
            <h2>{props.item.price + " kr"}</h2>
            <p>Bryggd på månadens bönor</p>
        </section>
    );
};

export default MenuItem;