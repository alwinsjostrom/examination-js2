import React from 'react';
import up from '../assets/arrow-up.svg';
import down from '../assets/arrow-down.svg';
import coffeeList from '../assets/coffee.json';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement, removeItems } from '../actions';

const BagItem = (props) => {

    //Variables regarding redux store
    const counter = useSelector(state => state.counters);
    const dispatch = useDispatch();

    //Increase the amount of an item by one
    const add = () => {
        dispatch(increment(props.chosen));
    };

    const subtract = () => {
        //If the amount is more than 0, decrease the amount of an item by one
        if (counter[props.chosen] > 0) {
            dispatch(decrement(props.chosen));
        };

        //If counter becomes 0, remove the item from the bag
        if (counter[props.chosen] <= 1) {
            dispatch(removeItems(props.chosen));
        };
    };

    return (
        <article className="bag__item">
            <h3 className="bag--item__title">{coffeeList[props.chosen].name}</h3>
            <button className="bag--item__up" onClick={add}><img src={up} alt="up"></img></button>
            <p className="bag--item__price">{coffeeList[props.chosen].price + " kr"}</p>
            <button className="bag--item__down" onClick={subtract}><img src={down} alt="down"></img></button>
            <p className="bag--item__amount">{counter[props.chosen]}</p>
        </article>
    );
};

export default BagItem;